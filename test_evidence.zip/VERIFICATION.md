
# Verification Instructions

1. Extract `manifest.json`, `manifest_signature.txt`, and `public_key.pem`.
2. Use OpenSSL or a script to verify the signature against the public key.
3. Validate that `results.json` matches the published blockchain hash.
        